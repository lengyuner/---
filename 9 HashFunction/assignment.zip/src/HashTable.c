#include <stdio.h>
#include <stdlib.h>
#include "HashTable.h"

/*
* args:
    m: length of hash table
    p: used in hash function
* return:
    table: hash table
* description:
    None.
*/
HashTable CreateEmptyHashTable(int m, int p)
{

}

/*
args:
    table: hash table
    key: key of data
    value: value of data
return:
    None
description:
    None.
*/
void HashTableInsert(HashTable table, int key, int value)
{

}

/*
args:
    table: hash table
    key: key of data
    ret: pointer to save value
return:
    bool: wether to find the key
description:
    if the key is found, the value is stored in ret and 
    returns 1, otherwise it returns 0.
*/
int HashTableFind(HashTable table, int key, int *ret)
{

}

/*
args:
    table: hash table
return:
    None
description:
    None.
*/
void DestroyHashTable(HashTable table)
{

}

/*
args:
    table: hash table
return:
    None
description:
    None.
*/
void PrintHashTable(HashTable table)
{
    int i;
    for (i = 0; i < table->m; ++i) {
        printf("%d: ", i);
        PrintLinkList(table->base[i]);
    }
}
